from flask import Flask, render_template, request, jsonify, send_file
import sqlite3
import re
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
import os
app = Flask(__name__)
user_session = {}
# --- Helper functions ---
def query_trains(source, destination):
    conn = sqlite3.connect('railway.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM trains WHERE LOWER(source)=? AND LOWER(destination)=?", (source.lower(), destination.lower()))
    trains = cursor.fetchall()
    conn.close()
    return trains

def get_train_by_name(train_name):
    conn = sqlite3.connect('railway.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM trains WHERE LOWER(train_name)=?", (train_name.lower(),))
    train = cursor.fetchone()
    conn.close()
    return train

def is_valid_future_date(date_text):
    try:
        travel_date = datetime.strptime(date_text, "%Y-%m-%d").date()
        today = datetime.now().date()
        return travel_date >= today
    except ValueError:
        return False

def generate_ticket_pdf(session_id, details):
    os.makedirs("tickets", exist_ok=True)
    file_path = f"tickets/ticket_{session_id}.pdf"

    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"Error deleting old ticket: {e}")
            return None

    doc = SimpleDocTemplate(file_path, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()

    # Title
    title = Paragraph("SMART RAIL - TICKET CONFIRMATION", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Ticket details table
    data = [
        ["Field", "Details"],
        ["Name", details['name']],
        ["Email", details['email']],
        ["Phone", details['phone']],
        ["Train", details['train'][1]],
        ["From", details['train'][2]],
        ["To", details['train'][3]],
        ["Date of Journey", details['date']],
        ["Departure", details['train'][4]],
        ["Arrival", details['train'][5]],
        ["Tickets Booked", str(details['ticket_count'])],
        ["Total Fare", f"₹{details['total_fare']}"],
    ]

    if "canceled" in details:
        data.append(["Tickets Canceled", str(details['canceled'])])
        data.append(["Refund Amount", f"₹{details['refund']}"])

    table = Table(data, colWidths=[150, 350])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR',(0,0),(-1,0),colors.black),
        ('ALIGN',(0,0),(-1,-1),'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0),(-1,0),14),
        ('BOTTOMPADDING', (0,0),(-1,0),12),
        ('BACKGROUND',(0,1),(-1,-1),colors.beige),
        ('GRID', (0,0), (-1,-1), 1, colors.black),
    ]))

    elements.append(table)
    doc.build(elements)

    return file_path

# --- Flask routes ---
@app.route('/download_ticket/<session_id>', methods=['GET'])
def download_ticket(session_id):
    file_path = f"tickets/ticket_{session_id}.pdf"
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({"error": "Ticket not found"}), 404

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message', '').strip()
    session_id = request.remote_addr
    session = user_session.get(session_id, {"stage": "start"})
    stage = session["stage"]
    response = ""

    if stage == "start":
        if "from" in user_input.lower() and "to" in user_input.lower():
            try:
                parts = user_input.lower().split("from")[1].split("to")
                source = parts[0].strip().capitalize()
                destination = parts[1].strip().capitalize()
                session.update({
                    "source": source,
                    "destination": destination,
                    "stage": "date_input"
                })
                response = f"Great! You’re traveling from {source} to {destination}.\nPlease enter your travel date (e.g., YYYY-MM-DD):"
            except:
                response = "Please provide the route like: 'from bheemgal to armoor'"
        else:
            response = "Hello! Tell me your route like 'from bheemgal to armoor' to get train info."

    elif stage == "date_input":
        if is_valid_future_date(user_input):
            session["date"] = user_input
            trains = query_trains(session["source"], session["destination"])
            if trains:
                session.update({
                    "trains": trains,
                    "stage": "train_selection"
                })
                response_lines = [f"Smartrail Bot: Trains from {session['source']} to {session['destination']} on {user_input}:"]
                for train in trains:
                    response_lines.append(
                        f"• {train[1]} | Dep: {train[4]} | Arr: {train[5]} | Seats: {train[6]} | Fare: ₹{train[7]}"
                    )
                response_lines.append("Please type the train name you want to book.")
                response = "\n".join(response_lines)
            else:
                response = f"No trains found from {session['source']} to {session['destination']}."
        else:
            response = "Invalid date. Please enter a future date in YYYY-MM-DD format."

    elif stage == "train_selection":
        selected_train = get_train_by_name(user_input)
        if selected_train:
            session.update({
                "selected_train": selected_train,
                "stage": "ticket_count_input"
            })
            response = f"You selected {selected_train[1]}.\nHow many tickets would you like to book?"
        else:
            response = "Train not found. Please enter a valid train name from the list."

    elif stage == "ticket_count_input":
        if user_input.isdigit() and int(user_input) > 0:
            ticket_count = int(user_input)
            selected_train = session["selected_train"]
            available_seats = selected_train[6]
            if ticket_count > available_seats:
                response = f"Sorry, only {available_seats} seats are available."
            else:
                total_fare = ticket_count * selected_train[7]
                session.update({
                    "ticket_count": ticket_count,
                    "total_fare": total_fare,
                    "stage": "user_details_input"
                })
                response = (
                    f"{ticket_count} ticket(s) selected. Total fare: ₹{total_fare}\n"
                    f"Please provide your details in the format:\n"
                    f"Name,Email,Phone\nExample: smartrail,smartrail@gmail.com,9876543210"
                )
        else:
            response = "Please enter a valid number of tickets to book."

    elif stage == "user_details_input":
        parts = [p.strip() for p in user_input.split(",")]
        if len(parts) == 3:
            name, email, phone = parts
            if re.match(r"[^@]+@[^@]+\.[^@]+", email) and re.match(r"\d{10,}", phone):
                train = session["selected_train"]
                count = session["ticket_count"]
                fare = session["total_fare"]
                travel_date = session["date"]

                session.update({
                    "stage": "confirmation_wait",
                    "user_details": {
                        "name": name,
                        "email": email,
                        "phone": phone
                    }
                })

                file_path = generate_ticket_pdf(session_id, {
                    "name": name,
                    "email": email,
                    "phone": phone,
                    "train": train,
                    "ticket_count": count,
                    "total_fare": fare,
                    "date": travel_date
                })

                if not file_path:
                    response = "Error generating your ticket. Please try again."
                else:
                    response = (
                        f"Booking confirmed for {name} ({count} ticket(s)) on train {train[1]} from {train[2]} to {train[3]}.\n"
                        f"Departure: {train[4]} | Arrival: {train[5]} | Date: {travel_date}\n"
                        f"Total Fare: ₹{fare}\n"
                        f"Download your ticket here: /download_ticket/{session_id}\n"
                        f"Do you want to cancel any tickets? (yes/no)"
                    )
            else:
                response = "Invalid email or phone format. Please use:\nName,Email,Phone"
        else:
            response = "Invalid format. Please provide your details like:\nsmartrail,smartrail@email.com,9876543210"

    elif stage == "confirmation_wait":
        if user_input.lower() == "yes":
            session["stage"] = "cancel_ticket_count"
            response = f"How many tickets do you want to cancel? (You booked {session['ticket_count']} ticket(s))"
        elif user_input.lower() == "no":
            session["stage"] = "done"
            response = (
                "Your ticket is confirmed. Thank you for booking with us!\n"
                f"Download your ticket here: /download_ticket/{session_id}"
            )
        else:
            response = "Please reply with 'yes' to cancel or 'no' to confirm your booking."

    elif stage == "cancel_ticket_count":
        if user_input.isdigit():
            cancel_count = int(user_input)
            booked = session["ticket_count"]
            if cancel_count > booked:
                response = f"You only booked {booked} ticket(s). Enter a valid number to cancel."
            else:
                remaining = booked - cancel_count
                refund = cancel_count * session["selected_train"][7]
                session["ticket_count"] = remaining
                session["stage"] = "done"

                file_path = generate_ticket_pdf(session_id, {
                    "name": session['user_details']['name'],
                    "email": session['user_details']['email'],
                    "phone": session['user_details']['phone'],
                    "train": session['selected_train'],
                    "ticket_count": remaining,
                    "total_fare": session["selected_train"][7] * remaining,
                    "canceled": cancel_count,
                    "refund": refund,
                    "date": session["date"]
                })

                if not file_path:
                    response = "Error updating your ticket. Please try again."
                else:
                    response = (
                        f"{cancel_count} ticket(s) canceled. ₹{refund} will be refunded.\n"
                        f"{remaining} ticket(s) remain. Thank you for using our service!\n"
                        f"Updated ticket: /download_ticket/{session_id}"
                    )
        else:
            response = "Please enter a valid number of tickets to cancel."

    elif stage == "done":
        if "from" in user_input.lower() and "to" in user_input.lower():
            user_session[session_id] = {"stage": "start"}
            return chat()
        else:
            response = "Booking session has ended. Start a new query like 'from bheemgal to armoor'."

    user_session[session_id] = session
    return jsonify({"response": response})

# --- Main ---

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
