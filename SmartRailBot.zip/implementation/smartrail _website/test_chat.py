import requests
import pyttsx3
import speech_recognition as sr

# Initialize text-to-speech engine
engine = pyttsx3.init()

def speak(text):
    print("Smartrail Bot:", text)
    engine.say(text)
    engine.runAndWait()

def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Speak your query (or say 'exit' to quit)...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
        except sr.WaitTimeoutError:
            speak("I didn't hear anything. Please try again.")
            return None

    try:
        user_input = recognizer.recognize_google(audio)
        print("customer:", user_input)
        return user_input
    except sr.UnknownValueError:
        speak("Sorry, I couldn't understand that. Please speak clearly.")
        return None
    except sr.RequestError:
        speak("Sorry, I can't reach the speech recognition service.")
        return None

# Mode selection
mode = ""
while mode not in ["1", "2"]:
    print("Choose your mode:")
    print("1. Voice Mode")
    print("2. Text Mode")
    mode = input("Enter 1 or 2: ").strip()

print("\nMode Selected:", "Voice" if mode == "1" else "Text")

# Main loop
while True:
    if mode == "1":
        user_input = listen()
    else:
        user_input = input("customer: ")

    if user_input:
        if user_input.lower() in ['exit', 'quit', 'stop']:
            speak("Goodbye!") if mode == "1" else print("Goodbye!")
            break

        try:
            response = requests.post("http://127.0.0.1:5000/chat", json={"message": user_input})
            bot_reply = response.json()["response"]
        except Exception as e:
            bot_reply = f"Error: {str(e)}"

        if mode == "1":
            speak(bot_reply)
        else:
            print("Smartrail Bot:", bot_reply)
